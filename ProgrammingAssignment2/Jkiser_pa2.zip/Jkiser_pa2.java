import java.util.Scanner;
import java.io.IOException;
import java.nio.file.Paths;

public class Jkiser_pa2 {
    
    public static void main(String[] args) throws IOException{
        // calls to gameControl method to start the game
        gameControl();
    }
    
    // this method creates the board based on the number given in the text file
    public static char[][] drawBoard(String fileName) 
            throws IOException{
        // creates a scanner to scan files
        Scanner fileScanner = new Scanner(Paths.get(fileName));
        // stores the first number in the txt file for board size
        int boardSize = fileScanner.nextInt();
        // initializes the board array
        char[][] board = new char [boardSize][boardSize];
        
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                board[i][j] = '.';
            }
        }
        //returns the initialized array
        return board;
    }
    
    // method to print the board
    public static void printBoard(char board[][]) {
       // nested for loop to loop through 2d array
       for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                System.out.print(board[i][j] + "");
            }
            System.out.println();
        }
    }
    
    // method fills board using plays from file
    public static char[][] fillBoard(char board[][], int row1, int col1, 
            int row2, int col2, char player) throws IOException{
        // this fills in the corners of the plays
        board[row1 - 1][col1 - 1] = player;
        board[row2 - 1][col2 - 1] = player;
        // this checks to see if the play starts on the left or right side of 
        // the board
        if (col1 - 1 < board.length / 2) {
            // if on the left side of the board, fill in the play
            for (int i = 0; i < row2 - 1; i++) {
                // makes sure the play isn't out of bounds
                if ((row1 - 1) + i < board.length && 
                        (col1 - 1) + i < board.length) {
                    // takes the original corner of the play and puts in the
                    // diagonal of it
                    board[(row1 - 1) + i][(col1 - 1) + i] = player;
                    }
            }
            // prints player 1's turn
            printBoard(board);
            System.out.println();
        } // otherwise, the play starts on the right side of the board
        else {
            for (int i = 0; i < row2 - 1; i++) {
                // makes sure the play isn't out of bounds
                if ((row2 - 1) + i < board.length && 
                    (col2 - 1) + i < board.length) {
                    // fills in the diagonal backwards since this corner is on
                    // the right side of the board
                    board[(row2 - 1) - i][(col2 - 1) + i] = player;
                }
            }
            // prints player 2's turn
            printBoard(board);
            System.out.println();
        }
        return board;
    }

    // runs the game
    public static char[][] play(String fileName, char board[][]) 
            throws IOException{
        // creates a scanner to scan files
        Scanner fileScanner = new Scanner(Paths.get(fileName));
        
        // skips the first line which contains n and k
        fileScanner.nextLine();
        // loops until no lines are in file
        while (fileScanner.hasNextLine()) {
            // if there is another int, store p1 values
            if (fileScanner.hasNextInt()) {
                // stores the row and column numbers player 1 plays
                int p1row1 = fileScanner.nextInt();
                int p1col1 = fileScanner.nextInt();
                int p1row2 = fileScanner.nextInt();
                int p1col2 = fileScanner.nextInt();
                // calls to fillboard method to fill the board for player 1
                board = fillBoard(board, p1row1, p1col1, p1row2, p1col2, 'X');
                // moves to the next line of the file
                fileScanner.nextLine();
            }
            
            // if there is another int, store p2 values
            if (fileScanner.hasNextInt()) {
                // stores the rows and column numbers player 2 plays
                int p2row1 = fileScanner.nextInt();
                int p2col1 = fileScanner.nextInt();
                int p2row2 = fileScanner.nextInt();
                int p2col2 = fileScanner.nextInt();
                // calls to fillboard method to fill the board for player 2
                board = fillBoard(board, p2row1, p2col1, p2row2, p2col2, 'O');
                // moves to the next line of the file
                fileScanner.nextLine();
            }
        }
        //returns the initialized array
        return board;
    }
    
    // counts the score
    public static void countScore(char board[][]) {
        // initializes counters for player 1 and 2
        int p1Counter = 0;
        int p2Counter = 0;
        // nested for loop to loop through the 2d array
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                // if inex contains x, increase p1 counter by 1
                if (board[i][j] == 'X') {
                    p1Counter++;
                } // otherwise if index contains o, increase p2 counter by 1
                else if (board[i][j] == 'O') {
                    p2Counter++;
                }
            }
        }
        // print both scores
        System.out.println("Player 1 Score: " + p1Counter);
        System.out.println("Player 2 Score: " + p2Counter);
        // print the winner depending on the score
        if (p1Counter > p2Counter) {
            System.out.println("Player 1 Wins!");
        }
        else if (p2Counter > p1Counter){
            System.out.println("Player 2 Wins!");
        }
        else {
            System.out.println("Draw!");
        }
    }
    
    // method to call all other methods
    public static void gameControl() throws IOException {
        // initializes the gameboard
        char[][] gameBoard = drawBoard("p2-5.txt");
        // plays using the gameboard
        gameBoard = play("p2-5.txt", gameBoard);
        // prints the final score
        countScore(gameBoard);
    }
}
