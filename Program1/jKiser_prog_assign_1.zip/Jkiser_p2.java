import java.util.Scanner;
import java.io.IOException;
import java.nio.file.Paths;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;


public class Jkiser_p2 {
    
    public static void main(String[] args) throws IOException{
       // fills up each matrix by calling to the fillArray method using the txt
       // file from p1.
       double[][] mat1 = fillArray("jKiser_mat1.txt");
       double[][] mat2 = fillArray("jKiser_mat2.txt");
       double[][] mat3 = fillArray("jKiser_mat3.txt");
       double[][] mat4 = fillArray("jKiser_mat4.txt");
       double[][] mat5 = fillArray("jKiser_mat5.txt");
       
       // calls to the printToTextAddition method which adds the two given
       // matrices and prints to a .txt file
       // In total there are 15 possible combinations.
       printToTextAddition(mat1, mat1, "jKiser_p2_out11.txt");
       printToTextAddition(mat1, mat2, "jKiser_p2_out12.txt");
       printToTextAddition(mat1, mat3, "jKiser_p2_out13.txt");
       printToTextAddition(mat1, mat4, "jKiser_p2_out14.txt");
       printToTextAddition(mat1, mat5, "jKiser_p2_out15.txt");
       
       printToTextAddition(mat2, mat2, "jKiser_p2_out22.txt");
       printToTextAddition(mat2, mat3, "jKiser_p2_out23.txt");
       printToTextAddition(mat2, mat4, "jKiser_p2_out24.txt");
       printToTextAddition(mat2, mat5, "jKiser_p2_out25.txt");
       
       printToTextAddition(mat3, mat3, "jKiser_p2_out33.txt");
       printToTextAddition(mat3, mat4, "jKiser_p2_out34.txt");
       printToTextAddition(mat3, mat5, "jKiser_p2_out35.txt");
       
       printToTextAddition(mat4, mat4, "jKiser_p2_out44.txt");
       printToTextAddition(mat4, mat5, "jKiser_p2_out45.txt");
       
       printToTextAddition(mat5, mat5, "jKiser_p2_out55.txt");
        
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextLine()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextLine()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                // I had to use math.round to fix some weird java decimal stuff
                mat[i][j] = matrixScanner.nextDouble();
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    // this method adds and prints the two given matrix to a .txt file
    public static void printToTextAddition(double mat1[][], double mat2[][], 
            String fileName) throws FileNotFoundException, IOException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        // checks if the number of columns and rows are equal
        if (mat1.length == mat2.length && mat1[0].length == mat2[0].length) {
            // if so, initializes the third matrix which is the sum of matrix
            // 1 and 2
            double[][] mat3 = new double [mat1.length][mat1[0].length];
            
            // loops through each element and adds them together and prints to 
            // .txt file
            for (int i = 0; i < mat1.length; i++) {
                for (int j = 0; j < mat1[i].length; j++) {
                    mat3[i][j] = mat1[i][j] + mat2[i][j];
                    out.print(mat3[i][j] + " ");
                }
                out.println();
            }
        } // if number of columns and rows aren't equal, it cannot be added
        else {
            // prints error message to file
            out.print("Error! These matrices cannot be added.");
        }
        // this closes the printwriter
        out.close();
    }
}