import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;


public class Jkiser_p1 {
    
    public static void main(String[] args) throws FileNotFoundException {
        // my name is Jamie Kiser so the 2d array will be 5x5 for mat1 through
        // mat3.
        
        // here I'm initializing a matrix and calling to my "fillArray" method
        // to fill each array with the desired numbers.
        // I used doubles to avoid any future problems reguarding decimals.
        double[][] mat1 = fillArray(5, 5, 1.0, 1.0);
        // For each matrix, i call to my "printToText" method.
        // This saves each matrix to a txt file.
        printToText(mat1, "jKiser_mat1.txt");
        
        double[][] mat2 = fillArray(5, 5, 4.0, 2.0);
        printToText(mat2, "jKiser_mat2.txt");
        
        double[][] mat3 = fillArray(5, 5, 0.3, 0.1);
        printToText(mat3, "jKiser_mat3.txt");
        
        // For mat 4 and 5 rows = 9 and columns = 11.
        double[][] mat4 = fillArray(9, 11, 3.0, 3.0);
        printToText(mat4, "jKiser_mat4.txt");
        
        double[][] mat5 = fillArray(9, 11, -5.0, 1.5);
        printToText(mat5, "jKiser_mat5.txt");
    }
    
    // this method fills the arrays
    public static double[][] fillArray(int row, int column, double matCount, 
            double matCountIncrement) {
        // initializes matrix to be filled
        double[][] mat = new double [row][column];
        
        // nested for loop to fill array
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < column; j++) {
                // I had to use math.round to fix some weird java decimal stuff
                mat[i][j] = Math.round(matCount * 10)/10.0;
                matCount+=matCountIncrement;
            }
        }
        // returns the matrix
        return mat;
    }
    
    public static void printToText(double mat[][], String fileName) 
            throws FileNotFoundException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        // this nested for loop goes through each element and prints them to
        // the file
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                out.print(mat[i][j] + " ");
            }
            out.println();
        }
        // this closes the printwriter
        out.close();
    }
}
