import java.util.Scanner;
import java.io.IOException;
import java.nio.file.Paths;
import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;


public class Jkiser_p3 {
    
    public static void main(String[] args) throws IOException{
       // fills up each matrix by calling to the fillArray method using the txt
       // file from p1.
       double[][] mat1 = fillArray("jKiser_mat1.txt");
       double[][] mat2 = fillArray("jKiser_mat2.txt");
       double[][] mat3 = fillArray("jKiser_mat3.txt");
       double[][] mat4 = fillArray("jKiser_mat4.txt");
       double[][] mat5 = fillArray("jKiser_mat5.txt");
       
       // calls to the printToTextMultiply method which multiplies the two given
       // matrices and prints to a .txt file
       // In total there are 15 possible combinations.
       printToTextMultiply(mat1, mat1, "jKiser_p3_out11.txt");
       printToTextMultiply(mat1, mat2, "jKiser_p3_out12.txt");
       printToTextMultiply(mat1, mat3, "jKiser_p3_out13.txt");
       printToTextMultiply(mat1, mat4, "jKiser_p3_out14.txt");
       printToTextMultiply(mat1, mat5, "jKiser_p3_out15.txt");
       
       printToTextMultiply(mat2, mat2, "jKiser_p3_out22.txt");
       printToTextMultiply(mat2, mat3, "jKiser_p3_out23.txt");
       printToTextMultiply(mat2, mat4, "jKiser_p3_out24.txt");
       printToTextMultiply(mat2, mat5, "jKiser_p3_out25.txt");
       
       printToTextMultiply(mat3, mat3, "jKiser_p3_out33.txt");
       printToTextMultiply(mat3, mat4, "jKiser_p3_out34.txt");
       printToTextMultiply(mat3, mat5, "jKiser_p3_out35.txt");
       
       printToTextMultiply(mat4, mat4, "jKiser_p3_out44.txt");
       printToTextMultiply(mat4, mat5, "jKiser_p3_out45.txt");
       
       printToTextMultiply(mat5, mat5, "jKiser_p3_out55.txt");
        
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextLine()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextLine()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                // I had to use math.round to fix some weird java decimal stuff
                mat[i][j] = matrixScanner.nextDouble();
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    // this method multiplies and prints the two given matrix to a .txt file
    public static void printToTextMultiply(double mat1[][], double mat2[][], 
            String fileName) throws FileNotFoundException, IOException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        // checks if column is equal to rows
        if (mat1[0].length == mat2.length) {
            // if so, initializes the third matrix which is the sum of matrix
            // 1 and 2
            double[][] mat3 = new double [mat1.length][mat1[0].length];
            
            // loops through each element and multiplies them together and 
            // prints to a .txt file
            for (int i = 0; i < mat1.length; i++) {
                for (int j = 0; j < mat2[0].length; j++) {
                    for (int k = 0; k < mat2.length; k++) {
                        mat3[i][j] += mat1[i][k] * mat2[k][j];
                    }
                    out.print(mat3[i][j] + " ");
                }
                out.println();
            }
        } // if mat1 column != mat2 row, it cannot be multiplied
        else {
            // prints error message to file
            out.print("Error! These matrices cannot be multiplied.");
        }
        // this closes the printwriter
        out.close();
    }
}
