import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.Scanner;
import static jkiser_pa4.jkiser_pa4_p1.printToFile;

public class jkiser_pa4_p3 {

    public static void main(String args[]) throws IOException{
        double[][] mat1 = fillArray("InputHW4_Part3.txt");
        printArray(mat1);
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextDouble()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextDouble()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (matrixScanner.hasNextDouble()) {
                    mat[i][j] = matrixScanner.nextDouble();
                }
                else {
                    break;
                }
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    public static void powerMethod(double mat[][]) {
        double[][] answer = new double [mat.length][mat[0].length];
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[0].length; j++) {
                //mat[i][j] 
            }
        }
    }
    
    // method to print arrays
    public static void printArray(double mat[][]) {
       // nested for loop to loop through 2d array
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }
}
