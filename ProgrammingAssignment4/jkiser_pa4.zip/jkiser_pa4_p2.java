import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.Scanner;
import static jkiser_pa4.jkiser_pa4_p1.printToFile;

public class jkiser_pa4_p2 {

    public static void main(String args[]) throws IOException {
        double[][] mat1 = fillArray("inputHW4_Part1_2.txt");
        //printArray(mat1);
        pointToPlane(mat1);
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextDouble()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextDouble()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (matrixScanner.hasNextDouble()) {
                    mat[i][j] = matrixScanner.nextDouble();
                }
                else {
                    break;
                }
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    // method to print arrays
    public static void printArray(double mat[][]) {
       // nested for loop to loop through 2d array
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    public static void pointToPlane(double mat[][]) 
            throws FileNotFoundException, IOException{
        // initializes all arrays and variables needed
        double[][] n = new double [1][3];
        double[][] x = new double [1][3];
        double[][] answer = new double [mat.length][mat[0].length/3];
        double mag;
        
        for (int i = 1; i < mat.length; i++) {
            for (int j = 0; j < mat[0].length/3; j++) {
                n[0][0] = mat[i][0];
                n[0][1] = mat[i][1];
                n[0][2] = mat[i][2];
                    
                x[0][0] = mat[i][6];
                x[0][1] = mat[i][7];
                x[0][2] = mat[i][8];
                
                mag = n[0][0] * n[0][0] + n[0][1] * n[0][1] + n[0][2] * n[0][2];
                mag = Math.sqrt(mag);
                
                
                answer[i - 1][j] = mag/n[0][0] * x[0][0] + mag/n[0][1] * 
                        x[0][1] + mag/n[0][2] * x[0][2];  
            }
        }
        
        printToFile(answer, "jkiser_output_1_2_B1.txt");
    }
    
    
    // method to print results to file
    public static void printToFile(double mat1[][], 
            String fileName) throws FileNotFoundException, IOException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        for (int i = 0; i < mat1.length; i++) {
            for (int j = 0; j < mat1[i].length; j++) {
                out.print(mat1[i][j] + " ");
            }
            out.println();
        }
        // this closes the printwriter
        out.close();
    }
}
