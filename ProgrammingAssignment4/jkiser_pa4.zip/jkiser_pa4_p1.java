import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.Scanner;

public class jkiser_pa4_p1 {

    public static void main(String args[]) throws IOException {
        double[][] mat1 = fillArray("inputHW4_Part1_2.txt");
        //printArray(mat1);
        parallelProject(mat1);
        perspectiveProject(mat1);
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextDouble()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextDouble()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (matrixScanner.hasNextDouble()) {
                    mat[i][j] = matrixScanner.nextDouble();
                }
                else {
                    break;
                }
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    // method to print arrays
    public static void printArray(double mat[][]) {
       // nested for loop to loop through 2d array
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    public static void parallelProject(double mat[][]) 
            throws FileNotFoundException, IOException{
        // initializes all arrays and variables needed
        double[][] answer = new double [mat.length - 1][mat[0].length];
        double[][] q = new double [1][3];
        double[][] n = new double [1][3];
        double[][] v = new double [1][3];
        double[][] x = new double [1][3];
        double qTimesn;
        double vTimesn;
        // runs through the equation "x' = x + (([q-x] dot n)/(v dot n))v"
        for (int i = 1; i < mat.length; i++) {
            for (int j = 0; j < mat[0].length; j++) {
                // initialize q
                q[0][0] = mat[0][0];
                q[0][1] = mat[0][1];
                q[0][2] = mat[0][2];
                // initialize n
                n[0][0] = mat[0][3];
                n[0][1] = mat[0][4];
                n[0][2] = mat[0][5];
                // initilize v
                v[0][0] = mat[0][6];
                v[0][1] = mat[0][7];
                v[0][2] = mat[0][8];
                
                if (j == 0) {
                    x[0][0] += mat[i][0];
                    x[0][1] += mat[i][1];
                    x[0][2] += mat[i][2];
                }
                else if (j == 1) {
                    x[0][0] += mat[i][3];
                    x[0][1] += mat[i][4];
                    x[0][2] += mat[i][5];
                }
                else {
                    x[0][0] += mat[i][6];
                    x[0][1] += mat[i][7];
                    x[0][2] += mat[i][8];
                }
                
                // subtract q and x
                q[0][0] -= x[0][0];
                q[0][1] -= x[0][1];
                q[0][2] -= x[0][2];
                //dot q and n
                q[0][0] *= n[0][0];
                q[0][1] *= n[0][1];
                q[0][2] *= n[0][2];
                qTimesn = q[0][0] + q[0][1] + q[0][2];
                //dot v and n
                n[0][0] *= v[0][0];
                n[0][1] *= v[0][1];
                n[0][2] *= v[0][2];
                vTimesn = n[0][0] + n[0][1] + n[0][2];
                //divide the dotted of the two
                qTimesn /= vTimesn;  
                // multiply v times whatever q times n divided by v times n is
                v[0][0] *= qTimesn;
                v[0][1] *= qTimesn;
                v[0][2] *= qTimesn;
                // add x and v
                x[0][0] += v[0][0];
                x[0][1] += v[0][1];
                x[0][2] += v[0][2];
                
                if (j == 0) {
                    answer[i - 1][0] += x[0][0];
                    answer[i - 1][1] += x[0][1];
                    answer[i - 1][2] += x[0][2];
                }
                else if (j == 1) {
                    answer[i - 1][3] += x[0][0];
                    answer[i - 1][4] += x[0][1];
                    answer[i - 1][5] += x[0][2];
                }
                else {
                    answer[i - 1][6] += x[0][0];
                    answer[i - 1][7] += x[0][1];
                    answer[i - 1][8] += x[0][2];
                }
            }
        }
        printToFile(answer, "jkiser_output_1_2_A1.txt");
    }
    
    public static void perspectiveProject(double mat[][]) 
            throws FileNotFoundException, IOException{
        // initializes all arrays and variables needed
        double[][] answer = new double [mat.length - 1][mat[0].length];
        double[][] q = new double [1][3];
        double[][] n = new double [1][3];
        double[][] x = new double [1][3];
        double qTimesn;
        double xTimesq;
        // runs through the equation "x' = x + (([q-x] dot n)/(v dot n))v"
        for (int i = 1; i < mat.length; i++) {
            for (int j = 0; j < 3; j++) {
                // initialize q
                q[0][0] = mat[0][0];
                q[0][1] = mat[0][1];
                q[0][2] = mat[0][2];
                // initialize n
                n[0][0] = mat[0][3];
                n[0][1] = mat[0][4];
                n[0][2] = mat[0][5];
                
                if (j == 0) {
                    x[0][0] += mat[i][0];
                    x[0][1] += mat[i][1];
                    x[0][2] += mat[i][2];
                }
                else if (j == 1) {
                    x[0][0] += mat[i][3];
                    x[0][1] += mat[i][4];
                    x[0][2] += mat[i][5];
                }
                else {
                    x[0][0] += mat[i][6];
                    x[0][1] += mat[i][7];
                    x[0][2] += mat[i][8];
                }
                
                //dot q and n
                q[0][0] *= n[0][0];
                q[0][1] *= n[0][1];
                q[0][2] *= n[0][2];
                qTimesn = q[0][0] + q[0][1] + q[0][2];
                
                //dot x and n
                n[0][0] *= x[0][0];
                n[0][1] *= x[0][1];
                n[0][2] *= x[0][2];
                xTimesq = n[0][0] + n[0][1] + n[0][2];
                
                qTimesn /= xTimesq;
                
                x[0][0] *= qTimesn;
                x[0][1] *= qTimesn;
                x[0][2] *= qTimesn;
                
                if (j == 0) {
                    answer[i - 1][0] += x[0][0];
                    answer[i - 1][1] += x[0][1];
                    answer[i - 1][2] += x[0][2];
                }
                else if (j == 1) {
                    answer[i - 1][3] += x[0][0];
                    answer[i - 1][4] += x[0][1];
                    answer[i - 1][5] += x[0][2];
                }
                else {
                    answer[i - 1][6] += x[0][0];
                    answer[i - 1][7] += x[0][1];
                    answer[i - 1][8] += x[0][2];
                }
            }
        }
        printToFile(answer, "jkiser_output_1_2_A2.txt");
    }
    
    // method to print results to file
    public static void printToFile(double mat1[][], 
            String fileName) throws FileNotFoundException, IOException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        for (int i = 0; i < mat1.length; i++) {
            for (int j = 0; j < mat1[i].length; j++) {
                out.print(mat1[i][j] + " ");
            }
            out.println();
        }
        // this closes the printwriter
        out.close();
    }
}
