import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.Scanner;

public class Jkiser_pa3_p1 {

    public static void main(String[] args) throws IOException {
        // handles finding x for test_input_1.txt
        double[][] mat1 = fillArray("test_input_1.txt");
        double[][] answerX1 = findX(mat1);
        printToFile(answerX1, "p1_test_output_1.txt");
        
        // handles finding x for test_input_2.txt
        double[][] mat2 = fillArray("test_input_2.txt");
        double[][] answerX2 = findX(mat2);
        printToFile(answerX2, "p1_test_output_2.txt");
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextInt()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextInt()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (matrixScanner.hasNextInt()) {
                    mat[i][j] = matrixScanner.nextInt();
                }
                else {
                    break;
                }
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    // method to print arrays
    public static void printArray(double mat[][]) {
       // nested for loop to loop through 2d array
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    // method extracts matrix a
    public static double[][] getMatA(double mat[][]) {
        // initializes matrix for A
        double[][] matA = new double [2][2];
       
        // fills matrix A with the first two column vectors
        matA[0][0] = mat[0][0];
        matA[0][1] = mat[0][1];
        matA[1][0] = mat[1][0];
        matA[1][1] = mat[1][1];
       
        // returns matrix A
        return matA;
    }
    
    // method extracts matrix b
    public static double[][] getMatB(double mat[][]) {
        // initializes matrix B
        double[][] matB = new double [2][1];
        
        // fills matrix B with the third column vector
        matB[0][0] = mat[0][2];
        matB[1][0] = mat[1][2];
       
        // returns matrix B
        return matB;
    }
    
    // gets the inverse of A
    public static double[][] getMatAInverse(double matA[][]) {
        // initialize 2d array to store inverse of A
        double[][] matAInverse = new double [2][2];
       
        // first step is to subtract n11 times n22 from n12 times n21
        double stepA = ((matA[0][0]*matA[1][1]) - (matA[0][1] * matA[1][0]));
        // that part is divided by 1
        stepA = 1 / stepA;
        
        // initializes array to store adjugate which is in the order:
        // n22, -n12, -n21, n11
        double[][] adjMat = new double[2][2];
        adjMat[0][0] = matA[1][1];
        adjMat[0][1] = -matA[0][1];
        adjMat[1][0] = -matA[1][0];
        adjMat[1][1] = matA[0][0];
        
        // multiplies the first part by the adjugate to get inverse
        for (int i = 0; i < matA.length; i++) {
            for (int j = 0; j < matA[i].length; j++) {
                matAInverse[i][j] = stepA * adjMat[i][j];
            }
        }
        
        // returns inverse of A
        return matAInverse;
    }
    
    // method to find X
    public static double[][] findX(double mat1[][]) {
        // calls to getMatA and getMatB method to get both matrices
        double[][] matA = getMatA(mat1);
        double[][] matB = getMatB(mat1);
        // uses matA to get inverse of A by calling to inverse method
        double[][] matAInverse = getMatAInverse(matA);
        // initializes x array
        double[][] answerX = new double[2][1];
        
        // does the multiplication between the inverse of A and the matrix B
        // stores in the answerX matrix
        answerX[0][0] = (matAInverse[0][0] * matB[0][0]) + 
                (matAInverse[0][1] * matB[1][0]);
        answerX[1][0] = (matAInverse[1][0] * matB[0][0]) + 
                (matAInverse[1][1] * matB[1][0]);
       
        // returns answerX matrix
        return answerX;
    }
    
    // method to print results to file
    public static void printToFile(double mat1[][], 
            String fileName) throws FileNotFoundException, IOException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        /*
        * If the array contains NaN, this means there was a divide by zero error
        * This means the system is inconsistent so that is printed to the file
        */
        if (Double.isNaN(mat1[0][0])) {
            out.print("System inconsistent");
        } // otherwise prints results to file
        else {
            for (int i = 0; i < mat1.length; i++) {
                for (int j = 0; j < mat1[i].length; j++) {
                    out.print(mat1[i][j] + " ");
                }
                out.println();
            }
        }
        // this closes the printwriter
        out.close();
    }
    
}
