import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.Scanner;


public class Jkiser_pa3_p3 {

    public static void main(String[] args) throws IOException {
        // handles finding area and distance for test_input_1.txt
        double[][] mat1 = fillArray("test_input_1.txt");
        getAreaAndDistance(mat1, "p3_test_output_1.txt");
        
        // handles finding area and distance for test_input_2.txt
        double[][] mat2 = fillArray("test_input_2.txt");
        getAreaAndDistance(mat2, "p3_test_output_2.txt");
        
        double[][] mat3 = fillArray("3d_test_input_1.txt");
        getAreaAndDistance(mat3, "p3_3d_test_output_1.txt");
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextInt()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextInt()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (matrixScanner.hasNextInt()) {
                    mat[i][j] = matrixScanner.nextInt();
                }
                else {
                    break;
                }
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    // method to print arrays
    public static void printArray(double mat[][]) {
       // nested for loop to loop through 2d array
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    // method to find the area of a 2d triangle
    public static double areaOf2d(double mat[][]) {
       // initialize answer variable
       double answer;
       
       // runs through the calculations in the equation:
       // 1/2|x1y2 + x2y3 + x3y1 - x1y3 - x2y1 - x3y2|
       answer = mat[0][0]*mat[1][1];
       answer += mat[0][1]*mat[1][2];
       answer += mat[0][2]*mat[1][0];
       answer -= mat[0][0]*mat[1][2];
       answer -= mat[0][1]*mat[1][0];
       answer -= mat[0][2]*mat[1][1];
       answer = (0.5)*Math.abs(answer);
       
       // returns answer
       return answer;
    }
    
    // method to find the area of a 3d triangle
    public static double areaOf3d(double mat[][]) {
        // initialize to hold answer
       double answer;
       // initialize arrays to hold ab matrix, ac matrix, and cross product of
       // ab and ac matrix
       double[][] abMat = new double[3][1];
       double[][] acMat = new double[3][1];
       double[][] crossMat = new double[3][1];
       // calculates abMat by subtracting B from A
       abMat[0][0] = mat[0][1]-mat[0][0];
       abMat[1][0] = mat[1][1]-mat[1][0];
       abMat[2][0] = mat[2][1]-mat[2][0];
       // calculates acMat by subtracting C from A
       acMat[0][0] = mat[0][2]-mat[0][0];
       acMat[1][0] = mat[1][2]-mat[1][0];
       acMat[2][0] = mat[2][2]-mat[2][0];
       // the beginning of the cross product where I add and subtract
       crossMat[0][0] = abMat[1][0] * acMat[2][0] - abMat[2][0] * acMat[1][0];
       crossMat[1][0] = abMat[0][0] * acMat[2][0] - abMat[2][0] * acMat[0][0];
       crossMat[1][0] *= -1;
       crossMat[2][0] = abMat[0][0] * acMat[1][0] - abMat[1][0] * acMat[0][0];
       // since java doesn't handle negative exponents well, this handles a 
       // number being squared if it's negative
       if (crossMat[0][0] < 0 || crossMat[1][0] < 0 || crossMat[2][0] < 0) {
           answer = crossMat[0][0] * crossMat[0][0] + crossMat[1][0] * 
                   -crossMat[1][0] + crossMat[2][0] * crossMat[2][0];
       }
       else {
           answer = crossMat[0][0] * crossMat[0][0] + crossMat[1][0] * 
               crossMat[1][0] + crossMat[2][0] * crossMat[2][0];
       }
       // this takes the square root of the cross product
       answer = Math.sqrt(answer);
       // this multiplies the final answer by 1/2 to get the final answer
       answer = 0.5 * answer;
       
       return answer;
    }
    
    // method to find the distance from a point to a line
    public static double lineDistance(double mat[][]) {
        // initialize answer variable
        double answer;
        // initiralize array to hold w matrix
        double[][] w = new double[2][1];
        // w is found by subtracting r from p which is the third and first
        // column in the original matrix
        w[0][0] = mat[0][2] - mat[0][0];
        w[1][0] = mat[1][2] - mat[1][0];
        // variable to hold magnitude of W
        // you get this by doing the square root of w1 squared plus w2 squared
        double magW = w[0][0] * w[0][0] + w[1][0] * w[1][0];
        magW = Math.sqrt(magW);
        // variable to store the magnitude of v
        // you get this b y doing the square root of v1 squared plus v2 squared
        double magV = mat[0][1] * mat[0][1] + mat[1][1] * mat[1][1];
        magV = Math.sqrt(magV);
        // variable to store v dotted with w
        double vDotw = mat[0][1] * w[0][0] + mat[1][1] * w[1][0];
        // the answer is v dotted with w over the magnitude of v times the 
        // magnitude of w
        magW *= magV;
        answer = vDotw / magW;
        // returns the answer
        return answer;
    }
    
    public static double planeDistance(double mat[][]) {
        // initialize answer, numberator, and denom variables
        double answer;
        double numerator;
        double denom;
        // numerator is A*x + B*y + C*z
        numerator = mat[0][1] * mat[0][0] + mat[1][1] * mat[1][0] + 
                mat[2][1] * mat[2][0];
        // takes the asbolute value
        numerator = Math.abs(numerator);
        // calculates denominator which is the square root of:
        // A^2 + B^2 + C^2
        denom = mat[0][1] * mat[0][1] + mat[1][1] * mat[1][1] + 
                mat[2][1] * mat[2][1];
        denom = Math.sqrt(denom);
        // answer is the numberator divided by the denominator
        answer = numerator / denom;
        // returns the answer
        return answer;
    }
    
    // this method gets the area and distance and checks if it's a 2d or 3d
    // matrix
    public static void getAreaAndDistance(double mat[][], 
            String fileName) throws FileNotFoundException, IOException{
        double area;
        double distance;
        // checks if matrix is 2d or 3d
        if (mat.length < 3) {
            // if 2d, runs 2d area and line distance methods
            area = areaOf2d(mat);
            distance = lineDistance(mat);
            // calls to print method to print answers to file
            printToFile(area, distance, fileName);
        } // otherwise handles 3d matrices
        else {
            // if it's a 3d matrix, calculates area of 3d triangle and distance
            // of a plane to a point
            area = areaOf3d(mat);
            distance = planeDistance(mat);
            // prints answers to file
            printToFile(area, distance, fileName);
        }
    }
    
    // method to print results to file
    public static void printToFile(double area, double distance, 
            String fileName) throws FileNotFoundException, IOException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        // prints to 4 significant digits
        out.printf("%.4f", area);
        out.println();
        out.printf("%.4f", distance);
        
        // this closes the printwriter
        out.close();
    }
}
