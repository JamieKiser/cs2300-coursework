import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.util.Scanner;

public class Jkiser_pa3_p2 {

    public static void main(String[] args) throws IOException {
        // handles finding x for test_input_1.txt
        double[][] mat1 = fillArray("test_input_1.txt");
        double[][] matA = getMatA(mat1);
        printArray(matA);
        //System.out.println(getDiag1(matA)[0]);
        //System.out.println(getDiag1(matA)[1]);
        //System.out.println(getDiag2(matA)[0]);
        //System.out.println(getDiag2(matA)[1]);
        // handles finding x for test_input_2.txt
        //double[][] mat2 = fillArray("test_input_2.txt");
    }
    
    // This method counts the rows in a matrix
    public static int countRows(String fileName) throws IOException {
        // initialize rows variable
        int rows = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // while file has another line, add one to the amount of rows
        while (matrixScanner.hasNextInt()) {
            rows++;
            matrixScanner.nextLine();
        }
        
        // return rows
        return rows;
    }
    
    // this method counts columns
    public static int countColumns(String fileName) throws IOException {
        // initialize column variable
        int columns = 0;
        
        // create new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // checks to see if file has more than one line.
        // if it does, counts amount of spaces in one line which is equal to
        // the amount of numbers, therefore giving the number of columns
        if (matrixScanner.hasNextInt()) {
            columns = matrixScanner.nextLine().split(" ").length;
        }
        
        // return number of columns
        return columns;
    }
    
    // this method fills the array from the given text file
    public static double[][] fillArray(String fileName) 
            throws IOException {
        
        // initializes rows and columns by calling to methods
        int rows = countRows(fileName);
        int columns = countColumns(fileName);
        
        // initializes matrix to be filled
        double[][] mat = new double [rows][columns];
        
        // creates new scanner for matrix file
        Scanner matrixScanner = new Scanner(Paths.get(fileName));
        
        // nested for loop to fill array
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (matrixScanner.hasNextInt()) {
                    mat[i][j] = matrixScanner.nextInt();
                }
                else {
                    break;
                }
            }
        }
        
        // returns the matrix
        return mat;
    }
    
    // method to print arrays
    public static void printArray(double mat[][]) {
       // nested for loop to loop through 2d array
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }
    
    // method extracts matrix a
    public static double[][] getMatA(double mat[][]) {
        // initializes matrix for A
        double[][] matA = new double [2][2];
       
        // fills matrix A with the first two column vectors
        matA[0][0] = mat[0][0];
        matA[0][1] = mat[0][1];
        matA[1][0] = mat[1][0];
        matA[1][1] = mat[1][1];
       
        // returns matrix A
        return matA;
    }
    
    public static double[] getDiag1(double mat[][]) {
        
        double[] diag = new double[2];
        diag[0] = mat [0][0];
        diag[1] = mat [1][1];
        
        return diag;
    }
    
    public static double[] getDiag2(double mat[][]) {
        
        double[] diag = new double[2];
        diag[0] = mat [1][0];
        diag[1] = mat [0][1];
        
        return diag;
    }
    
    // method to print results to file
    public static void printToFile(double mat1[][], 
            String fileName) throws FileNotFoundException, IOException {
        // This creates the file the matrix will be saved to.
        File file = new File ("./" + fileName);
        
        // this opens the printwriter to write to the file
        PrintWriter out = new PrintWriter(file);
        
        /*
        * If the array contains NaN, this means there was a divide by zero error
        * This means the system is inconsistent so that is printed to the file
        */
        if (Double.isNaN(mat1[0][0])) {
            out.print("System inconsistent");
        } // otherwise prints results to file
        else {
            for (int i = 0; i < mat1.length; i++) {
                for (int j = 0; j < mat1[i].length; j++) {
                    out.print(mat1[i][j] + " ");
                }
                out.println();
            }
        }
        // this closes the printwriter
        out.close();
    }
}
